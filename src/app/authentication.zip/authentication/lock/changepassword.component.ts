import { Component } from '@angular/core';

@Component({
  selector: 'app-changepassword',
  templateUrl: './changePassword.component.html'
})
export class changepasswordComponent {
  constructor() {}
}
